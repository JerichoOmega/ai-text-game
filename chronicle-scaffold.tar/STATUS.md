# Production Hardening — Status

Written against the 14-phase hardening prompt. Graded honestly: **Done**
means implemented and internally consistent (verified by manual type-surface
review, not by running the toolchain — no network in this environment, see
README). **Partial** means real code exists but doesn't cover the full
phase. **Deferred** means not started, with the reason why.

| Phase | Status | Notes |
|---|---|---|
| 1. Architecture Audit | Done | See below — this whole pass *is* the audit-then-refactor. |
| 2. Event Bus | Done | `EventBus.ts` + `eventSubscribers/*`. EventEngine no longer contains reactive logic. |
| 3. Simulation Engine | Done | `SimulationEngine.ts` — fixed pipeline, TimeSystem now a compatibility shim over it. |
| 4. World Managers | Partial | `WeatherManager` added (genuinely new logic). The other 13 named managers were deliberately **not** created as wrapper classes — see rationale below. |
| 5. Data-Driven Content | Deferred | Not started. |
| 6. Chronicle System | Partial | `HistoryLog.generateYearNarrative()` renders a readable per-year summary. No dedicated chronicle screen yet (history screen shows a flat list, not the narrative). |
| 7. NPC Memory | Done | Expanded `MemoryType`, importance-weighted decay (major events don't fade, routine ones do), `decayed` flag now actually computed and used by `getProminentMemories()`. |
| 8. Emergent Quest Generator | Unchanged | Already implemented in the vertical slice; not touched this pass. Still only 3 templates — more chains (crop failure → prices → hunters → poachers → rangers) are content work, not architecture, and are deferred. |
| 9. Reputation | Partial | Added `ReputationScope` (global/kingdom/settlement/faction). Guild/religion/family scopes **not** added — those entity types don't exist in the domain layer, so the scope would be a label with nothing behind it. Reputation doesn't yet influence prices/dialogue/etc. — `ReputationSystem` exists but isn't called from anywhere yet. |
| 10. Save System | Partial | Weather now persists, forward/backward-compatible (`saveVersion` bumped, old saves default gracefully). No RNG seed persisted — `Math.random()` is used directly, so save/load does not currently reproduce identical future rolls. Simulation clock (`currentDate`) does persist. |
| 11. Performance | Deferred | Not started beyond what already existed (indexed SQLite columns from the original pass). No profiling has been done; "prepare for thousands of NPCs" hasn't been tested at that scale. |
| 12. Testing | Partial | 6 test files under `tests/` (added `worldTransaction.test.ts` and `testHelpers.ts` since this was written) covering time math, NPC memory decay, EventBus ordering/isolation, quest conditionality, and world-state transaction safety — all pure-logic, no SQLite/RN dependency. **Executed and verified**: `npm test` — 20/20 passing, 0 failing, 0 skipped (required a test-only `tsconfig.test.json` to fix `tsx`'s alias resolution — see README's "Running the tests" section). `npm run typecheck` remains environment-blocked (`expo` package not installed, unrelated to test execution). No CI, no combat/save-load/economy tests yet. |
| 13. Documentation | Done (this pass) | This file + README updates. Architecture diagrams and a formal extension guide are not written. |
| 14. Code Quality | Partial | This refactor itself is a cohesion/coupling improvement (Phase 2/3). No dedicated duplication/naming audit pass beyond what fell out of the refactor. |

## Phase 1 audit, in short

What was already sound and preserved as-is: the domain/data/systems/state/
presentation split, the SQLite JSON-blob-per-table persistence model, the
seed data shape, the component/screen layer. Nothing there needed
rewriting.

What had the coupling problem the prompt named: `EventEngine` owned a
`CONSEQUENCE_RULES` table that directly called `NPCMemorySystem.remember()`
and mutated settlements inline — i.e. exactly "one gameplay system directly
calling another while reacting to an event." That's what moved to
`eventSubscribers/`. `TimeSystem` owned the day-loop directly rather than
delegating to a dedicated simulation class — that's what `SimulationEngine`
now owns, with `TimeSystem` kept only so nothing calling it breaks.

## Why 13 of 14 named managers weren't created

`CharacterManager`, `SettlementManager`, `FactionManager`, `EconomyManager`,
`QuestManager`, `DialogueManager`, `CombatManager`, `InventoryManager`,
`RelationshipManager`, `TimeManager` etc. would each be a class whose entire
body is "call the existing system of (almost) the same name." That's
indirection with no behavior behind it — the kind of thing Phase 14 asks to
eliminate, not add. `NPCMemorySystem` already *is* the character/
relationship manager; `EconomySystem` already *is* the economy manager.
`WeatherManager` got made because weather is new — there was no existing
system to wrap. If a system's responsibilities genuinely outgrow one file
(e.g. `CombatEngine` sprouts targeting AI, an ability system, and loot
tables as separate concerns), that's the signal to split it into a real
manager + supporting files, not before.

## Recommended order for what's actually next

1. **Wire something to consume `ReputationSystem`** — right now it's dead
   code. Cheapest win: quest completion should call `adjust()` using the
   scope+regionId now available. This also finally exercises the objective-
   completion gap noted in the original README.
2. **Combat → quest completion loop** — still the biggest hole in "does the
   core loop provably work end to end."
3. ~~Run `npm test` for real~~ — done in a later pass: fixed (`tsx`
   couldn't resolve value-level `@/` imports because `tsconfig.json`'s
   `extends: "expo/tsconfig.base"` doesn't resolve without a full
   `npm install`; fixed with a test-only `tsconfig.test.json`, no source
   changes). 20/20 passing. `npm run typecheck` is still environment-
   blocked for the same underlying reason (`expo` not installed) — that
   part of the original concern remains open, just no longer conflated
   with test execution.
4. Persist an RNG seed if determinism-on-reload actually matters for your
   design (it matters a lot for Phase 12's "must remain deterministic" if
   that's meant to include save/load, less if it's only meant to describe
   same-session pipeline ordering).
