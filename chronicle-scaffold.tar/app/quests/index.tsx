import React from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useWorldStore } from "@/state/useWorldStore";
import { useTheme } from "@/presentation/theme/useTheme";
import { QuestCard } from "@/presentation/components/QuestCard";

export default function QuestsScreen() {
  const theme = useTheme();
  const world = useWorldStore((s) => s.world);

  const quests = world
    ? Object.values(world.quests).filter((q) => q.status === "available" || q.status === "active")
    : [];

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]} edges={["bottom"]}>
      <ScrollView contentContainerStyle={{ paddingBottom: 16 }}>
        {quests.length === 0 && (
          <Text style={{ color: theme.inkMuted, fontStyle: "italic", marginTop: 24, textAlign: "center" }}>
            No quests right now. Rest a day and see what the world brings.
          </Text>
        )}
        {quests.map((quest) => (
          <QuestCard key={quest.id} quest={quest} />
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 16, paddingTop: 12 },
});
